test_that("lucksay gives lucky", {
  expect_equal(lucksay(), "lucky")
})
