lucksay <- function() {
  "lucky"
}