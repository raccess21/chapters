ducksay <- function(phrase = "hello, world") {
  paste(
    phrase,
    ">(. )___",
    " (_____/",
    sep = "\n"
  )
}